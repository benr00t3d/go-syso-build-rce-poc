package evil

const Value = 1
